#!/bin/sh -l

cd ~/cdmetapop/CDMetaPOP_v3.08
python3 ./src/CDmetaPOP.py ./inputs/Adaptive_Run10 RunVars_SIDP_RT.csv ../../../../../../mnt/DataDrive1/data/akwilliams/outputs/Adaptive_Run_10/RT.out
