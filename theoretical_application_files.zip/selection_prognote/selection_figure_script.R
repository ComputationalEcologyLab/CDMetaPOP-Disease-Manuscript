library(tidyverse)

# allele frequencies ------------------------------------------------------

# Set base directory
base_dir <- "CDMetaPOP_v3.03/outputs/July09_final.out1752040316/"
batches <- paste0("batch", 0:4)

# Function to calculate allele frequencies
calc_allele_freq <- function(file, year, run) {
  df <- read.csv(file)[, 21:28]
  freqs <- colSums(df) / (2 * nrow(df))
  tibble(
    Year = year,
    Run = run,
    Locus = rep(paste0("Locus ", 1:4), each = 2),
    Allele = rep(c("p", "q"), times = 4),
    Frequency = freqs
  )
}

# Collect summary allele frequencies for all batches
all_batches_summary <- map_dfr(batches, function(batch) {
  run_folders <- paste0("run0", batch, "mc", 0:99, "species0")
  
  all_freqs <- map_dfr(run_folders, function(run) {
    map_dfr(0:99, function(i) {
      file <- file.path(base_dir, run, paste0("ind", i, ".csv"))
      if (file.exists(file)) {
        calc_allele_freq(file, i, run)
      } else {
        warning(paste("Missing file:", file))
        return(NULL)
      }
    })
  })
  
  # Summarize across runs
  summary_df <- all_freqs %>%
    group_by(Year, Locus, Allele) %>%
    summarise(
      mean = mean(Frequency),
      sd = sd(Frequency),
      .groups = "drop"
    ) %>%
    mutate(
      Batch = paste0(batch),
      Allele = factor(Allele, levels = c("p", "q"))
    )
  
  return(summary_df)
})

## Clean data...

all_batches_summary <- all_batches_summary %>%
  rename(Scenario = Batch) %>%
  mutate(Scenario = recode(Scenario,
                           "batch0" = "Null",
                           "batch1" = "Neutral",
                           "batch2" = "Resistance",
                           "batch3" = "Tolerance",
                           "batch4" = "Res. + Tol.")) %>%
  mutate(Scenario = factor(Scenario, levels = c("Null", "Neutral", "Resistance", 
                                                "Tolerance", "Res. + Tol."))) %>%
  mutate(Locus = recode(Locus,
                        "Locus 1" = "Neutral 1",
                        "Locus 2" = "Neutral 2",
                        "Locus 3" = "Resistant",
                        "Locus 4" = "Tolerant"))

## Plot...

Allele_Freq <- ggplot(all_batches_summary, aes(x = Year, y = mean, color = Allele, fill = Allele)) +
  geom_line(linewidth = 1) +
  geom_ribbon(aes(ymin = mean - sd, ymax = mean + sd), alpha = 0.2, color = NA) +
  facet_grid(Locus ~ Scenario) +
  scale_x_continuous(limits = c(0, 100), breaks = seq(0,100, by = 50),
                     name = "Year", sec.axis = sec_axis(~ ., name = "Scenario"))+
  scale_y_continuous(name = "Allele Frequency", sec.axis = sec_axis(~ ., name = "Locus")) +
  theme_minimal(base_size = 12) +
  theme(axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),
        axis.text.x.top = element_blank(),
        axis.ticks.x.top = element_blank(),
        panel.border = element_rect(color = "black", 
                                    fill = NA,  linewidth = 0.3)) +
  labs(
    title = "b",
    y = "Allele Frequency",
    x = "Year",
    color = "Allele",
    fill = "Allele"
  )
Allele_Freq
ggsave(
  filename = "/mnt/DataDrive1/data/akwilliams/output_figures/July09_Final/allele_freq_all_batches.png",
  plot = Allele_Freq,
  width = 12,
  height = 8,
  dpi = 300,
  bg = "white"
)


# population size ---------------------------------------------------------

batch_nums <- 0:4

# Collect all plot data
all_plot_data <- map_dfr(batch_nums, function(batch) {
  
  mc_paths <- paste0("CDMetaPOP_v3.03/outputs/July09_final.out1752040316/run0batch", 
                     batch, "mc", 0:99, "species0/summary_popAllTime_DiseaseStates.csv")
  
  all_reps <- lapply(mc_paths, function(path){
    df <- read_csv(path, show_col_types = FALSE)
    
    df %>%
      mutate(SIRD = sub("\\|.*", "", States_SecondUpdate)) %>%
      separate(SIRD, into = c("S", "I", "R", "D"), sep = ";", convert = TRUE) #%>%
    #mutate(D = cumsum(D))  # cumulative deaths
  })
  
  combined_df <- bind_rows(all_reps, .id = "replicate")
  
  summary_df <- combined_df %>%
    mutate(N = S + I + R) %>%  # Total population size
    group_by(Year) %>%
    summarise(
      S_mean = mean(S), S_sd = sd(S),
      I_mean = mean(I), I_sd = sd(I),
      R_mean = mean(R), R_sd = sd(R),
      D_mean = mean(D), D_sd = sd(D),
      N_mean = mean(N), N_sd = sd(N),
      .groups = "drop"
    )
  
  plot_df <- summary_df %>%
    pivot_longer(cols = -Year, names_to = c("State", ".value"),
                 names_pattern = "(.)_(mean|sd)") %>%
    mutate(
      Batch = paste0("Batch ", batch),
      State = factor(State, levels = c("S", "I", "R", "D", "N"))
    )
  
  return(plot_df)
})

## Cleaning data...

# remove N - not needed for final figure: 
all_plot_data <- all_plot_data %>%
  filter(!State == "N") %>%
  rename(Scenario = Batch) %>%
  mutate(Scenario = recode(Scenario,
                           "Batch 0" = "Null",
                           "Batch 1" = "Neutral",
                           "Batch 2" = "Resistance",
                           "Batch 3" = "Tolerance",
                           "Batch 4" = "Res. + Tol.")) %>%
  mutate(Scenario = factor(Scenario, levels = c("Null", "Neutral", "Resistance", 
                                                "Tolerance", "Res. + Tol.")))

## Plot...

SIRD <- ggplot(all_plot_data, aes(x = Year, y = mean, color = Scenario, 
                               fill = Scenario, shape = Scenario)) +
  geom_line(size = 0.5) +
  geom_point(data = all_plot_data %>% filter(Year %% 10 == 0), size = 2, color = "black") +
  geom_ribbon(aes(ymin = mean - sd, ymax = mean + sd), alpha = 0.15, color = NA) +
  facet_wrap(~ State, ncol = 2, scales = "free_y") +  # 4 panels: S, I, R, D
  scale_shape_manual(values = c(0,1,2,4,5)) +
  #scale_x_continuous(limits = c(0,100)) +
  theme_minimal(base_size = 12) +
  theme(panel.border = element_rect(color = "black", 
                                    fill = NA,  linewidth = 0.5)) +
  labs(
    title = "a",
    x = "",
    y = "Population Size",
    color = "Scenario",
    fill = "Scenario",
    linetype = "Scenario"
  )
SIRD
ggsave("/mnt/DataDrive1/data/akwilliams/output_figures/July09_Final/SIRD_by_state.png", SIRD,
       width = 12, height = 7, dpi = 300, bg = "white")


# combine plots -----------------------------------------------------------

library(patchwork)

png(filename = "/mnt/DataDrive1/data/akwilliams/output_figures/July09_Final/SIRD+allele_freq.png",
    width = 8, height = 9, units = "in", res = 300)
SIRD / Allele_Freq
dev.off()
